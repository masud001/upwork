// data for home chart
const MiscEquity = [26, 36, 42, 38, 40, 30, 12, 100, 150, 20, 200];
const NetCash = [34, 44, 33, 24, 25, 28, 25, 10, 50, 60, 30];
const Investments = [16, 13, 25, 33, 40, 33, 45, 20, 30, 40, 50];
const HouseEquity = [5, 9, 10, 9, 18, 19, 20, 5, 10, 30, 30];
const xData = [
	2010,
	2011,
	2012,
	2013,
	2014,
	2015,
	2016,
	2017,
	2018,
	2019,
	2020,
];

const MiscEquity2 = [26, 36, 42, 38, 40];
const NetCash2 = [34, 44, 33, 24, 25];
const Investments2 = [16, 13, 25, 33, 40];
const HouseEquity2 = [5, 9, 10, 9, 18];
const xData2 = [2010, 2011, 2012, 2013, 2014];
